from app import db, User
from dotenv import load_dotenv
import os

load_dotenv()

def update_password(username, new_password):
    user = User.query.filter_by(username=username).first()
    if user:
        user.password = new_password
        db.session.commit()
        print(f'Password updated for {username}')
    else:
        print('User not found')

if __name__ == '__main__':
    # Change this password for the admin user
    update_password(os.getenv('ADMIN_USERNAME'), 'NewStrongPassword123')
